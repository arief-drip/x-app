export PATH="$PATH:./node_modules/.bin:$HOME/.local/bin"
export EDITOR="code --wait"
export CLICOLOR=1
export LSCOLORS=ExFxBxDxCxegedabagacad
