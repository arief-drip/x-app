// loop-functional.ts
// Functional programming loop patterns with practical use cases

// ============================================
// Sample Data
// ============================================

interface Employee {
  id: number;
  name: string;
  department: string;
  salary: number;
  yearsOfService: number;
  isActive: boolean;
}

interface Transaction {
  id: string;
  amount: number;
  type: "credit" | "debit";
  category: string;
  date: string;
}

const employees: Employee[] = [
  { id: 1, name: "John Doe", department: "Engineering", salary: 90000, yearsOfService: 3, isActive: true },
  { id: 2, name: "Jane Smith", department: "Engineering", salary: 110000, yearsOfService: 5, isActive: true },
  { id: 3, name: "Bob Johnson", department: "Sales", salary: 75000, yearsOfService: 2, isActive: false },
  { id: 4, name: "Alice Brown", department: "Marketing", salary: 80000, yearsOfService: 4, isActive: true },
  { id: 5, name: "Charlie Wilson", department: "Sales", salary: 85000, yearsOfService: 6, isActive: true },
  { id: 6, name: "Diana Lee", department: "Engineering", salary: 95000, yearsOfService: 1, isActive: true },
];

const transactions: Transaction[] = [
  { id: "TXN001", amount: 5000, type: "credit", category: "Salary", date: "2024-01-01" },
  { id: "TXN002", amount: 1200, type: "debit", category: "Rent", date: "2024-01-02" },
  { id: "TXN003", amount: 300, type: "debit", category: "Groceries", date: "2024-01-03" },
  { id: "TXN004", amount: 2000, type: "credit", category: "Freelance", date: "2024-01-05" },
  { id: "TXN005", amount: 150, type: "debit", category: "Transport", date: "2024-01-06" },
  { id: "TXN006", amount: 800, type: "debit", category: "Utilities", date: "2024-01-07" },
];

// ============================================
// 1. forEach
// Send notification to each active employee about annual review
// ============================================

interface Notification {
  employeeId: number;
  employeeName: string;
  message: string;
  priority: string;
}

function generateReviewNotifications(staff: Employee[]): Notification[] {
  const notifications: Notification[] = [];

  staff.forEach((employee: Employee): void => {
    if (employee.isActive) {
      const priority: string = employee.yearsOfService >= 5 ? "High" : "Normal";
      notifications.push({
        employeeId: employee.id,
        employeeName: employee.name,
        message: `Hi ${employee.name}, your annual performance review is scheduled. Please prepare your self-assessment.`,
        priority,
      });
    }
  });

  return notifications;
}

const reviewNotifications = generateReviewNotifications(employees);
console.log("Review Notifications:");
reviewNotifications.forEach((notif: Notification): void => {
  console.log(`  [${notif.priority}] ${notif.employeeName}: ${notif.message.substring(0, 50)}...`);
});

// ============================================
// 2. map
// Transform employee data to public profile format
// ============================================

interface PublicProfile {
  displayName: string;
  department: string;
  tenure: string;
  seniorityLevel: string;
}

function generatePublicProfiles(staff: Employee[]): PublicProfile[] {
  return staff.map((employee: Employee): PublicProfile => {
    const seniorityLevel: string =
      employee.yearsOfService >= 5 ? "Senior" :
      employee.yearsOfService >= 3 ? "Mid-level" : "Junior";

    return {
      displayName: employee.name.split(" ")[0], // First name only
      department: employee.department,
      tenure: `${employee.yearsOfService} year${employee.yearsOfService !== 1 ? "s" : ""}`,
      seniorityLevel,
    };
  });
}

const publicProfiles = generatePublicProfiles(employees);
console.log("\nPublic Profiles:", publicProfiles);

// ============================================
// 3. filter
// Find eligible employees for bonus (active + 3+ years service)
// ============================================

interface BonusEligibility {
  employee: Employee;
  bonusPercentage: number;
  estimatedBonus: number;
}

function findBonusEligibleEmployees(staff: Employee[]): BonusEligibility[] {
  return staff
    .filter((employee: Employee): boolean =>
      employee.isActive && employee.yearsOfService >= 3
    )
    .map((employee: Employee): BonusEligibility => {
      const bonusPercentage: number =
        employee.yearsOfService >= 5 ? 15 :
        employee.yearsOfService >= 3 ? 10 : 0;

      return {
        employee,
        bonusPercentage,
        estimatedBonus: Math.round(employee.salary * (bonusPercentage / 100)),
      };
    });
}

const bonusEligible = findBonusEligibleEmployees(employees);
console.log("\nBonus Eligible Employees:");
bonusEligible.forEach((item: BonusEligibility): void => {
  console.log(`  ${item.employee.name}: ${item.bonusPercentage}% bonus = $${item.estimatedBonus}`);
});

// ============================================
// 4. reduce
// Calculate financial summary from transactions
// ============================================

interface FinancialSummary {
  totalIncome: number;
  totalExpenses: number;
  netBalance: number;
  categoryBreakdown: Record<string, number>;
  transactionCount: number;
}

function calculateFinancialSummary(txnList: Transaction[]): FinancialSummary {
  return txnList.reduce((summary: FinancialSummary, txn: Transaction): FinancialSummary => {
    // Update income/expenses
    if (txn.type === "credit") {
      summary.totalIncome += txn.amount;
    } else {
      summary.totalExpenses += txn.amount;
    }

    // Update category breakdown
    summary.categoryBreakdown[txn.category] =
      (summary.categoryBreakdown[txn.category] || 0) + txn.amount;

    // Update count
    summary.transactionCount++;

    return summary;
  }, {
    totalIncome: 0,
    totalExpenses: 0,
    netBalance: 0,
    categoryBreakdown: {},
    transactionCount: 0,
  });
}

const financialSummary = calculateFinancialSummary(transactions);
financialSummary.netBalance = financialSummary.totalIncome - financialSummary.totalExpenses;
console.log("\nFinancial Summary:", financialSummary);

// ============================================
// 5. Method chaining (map + filter + sort)
// Generate department salary report with rankings
// ============================================

interface DepartmentSalaryReport {
  department: string;
  employeeCount: number;
  averageSalary: number;
  totalSalary: number;
  salaryRange: { min: number; max: number };
}

function generateDepartmentSalaryReport(staff: Employee[]): DepartmentSalaryReport[] {
  // Get unique departments
  const departments: string[] = [...new Set(staff.map((e: Employee): string => e.department))];

  return departments
    .map((dept: string): DepartmentSalaryReport => {
      const deptEmployees: Employee[] = staff.filter((e: Employee): boolean => e.department === dept);
      const salaries: number[] = deptEmployees.map((e: Employee): number => e.salary);

      return {
        department: dept,
        employeeCount: deptEmployees.length,
        averageSalary: Math.round(salaries.reduce((a: number, b: number): number => a + b, 0) / salaries.length),
        totalSalary: salaries.reduce((a: number, b: number): number => a + b, 0),
        salaryRange: {
          min: Math.min(...salaries),
          max: Math.max(...salaries),
        },
      };
    })
    .filter((report: DepartmentSalaryReport): boolean => report.employeeCount >= 2) // Only departments with 2+ employees
    .sort((a: DepartmentSalaryReport, b: DepartmentSalaryReport): number => b.averageSalary - a.averageSalary); // Sort by avg salary desc
}

const salaryReport = generateDepartmentSalaryReport(employees);
console.log("\nDepartment Salary Report (sorted by avg salary):");
salaryReport.forEach((report: DepartmentSalaryReport, index: number): void => {
  console.log(`  ${index + 1}. ${report.department}: Avg $${report.averageSalary.toLocaleString()} (${report.employeeCount} employees)`);
});

// ============================================
// Bonus: Complex chaining - Find top performers by department
// ============================================

interface TopPerformer {
  department: string;
  topEmployee: string;
  salary: number;
  yearsOfService: number;
}

function findTopPerformersByDepartment(staff: Employee[]): TopPerformer[] {
  const departments: string[] = [...new Set(staff.map((e: Employee): string => e.department))];

  return departments
    .map((dept: string): TopPerformer | null => {
      const deptEmployees: Employee[] = staff
        .filter((e: Employee): boolean => e.department === dept && e.isActive)
        .sort((a: Employee, b: Employee): number => {
          // Sort by years of service (desc), then by salary (desc)
          if (b.yearsOfService !== a.yearsOfService) {
            return b.yearsOfService - a.yearsOfService;
          }
          return b.salary - a.salary;
        });

      if (deptEmployees.length === 0) return null;

      const top: Employee = deptEmployees[0];
      return {
        department: dept,
        topEmployee: top.name,
        salary: top.salary,
        yearsOfService: top.yearsOfService,
      };
    })
    .filter((result: TopPerformer | null): result is TopPerformer => result !== null)
    .sort((a: TopPerformer, b: TopPerformer): number => b.yearsOfService - a.yearsOfService);
}

const topPerformers = findTopPerformersByDepartment(employees);
console.log("\nTop Performers by Department:");
topPerformers.forEach((performer: TopPerformer): void => {
  console.log(`  ${performer.department}: ${performer.topEmployee} (${performer.yearsOfService} years)`);
});
