// loop-imperative.ts
// Classic imperative loop patterns with practical use cases

// ============================================
// Sample Data
// ============================================

interface Product {
  id: number;
  name: string;
  price: number;
  category: string;
  inStock: boolean;
}

interface Student {
  name: string;
  scores: number[];
}

const products: Product[] = [
  { id: 1, name: "Laptop", price: 1200, category: "Electronics", inStock: true },
  { id: 2, name: "Mouse", price: 25, category: "Electronics", inStock: true },
  { id: 3, name: "Desk", price: 300, category: "Furniture", inStock: false },
  { id: 4, name: "Chair", price: 150, category: "Furniture", inStock: true },
  { id: 5, name: "Monitor", price: 400, category: "Electronics", inStock: true },
];

const students: Student[] = [
  { name: "Alice", scores: [85, 90, 78] },
  { name: "Bob", scores: [92, 88, 95] },
  { name: "Charlie", scores: [70, 75, 80] },
];

const orderStatuses: Record<string, string> = {
  ORD001: "Shipped",
  ORD002: "Processing",
  ORD003: "Delivered",
  ORD004: "Pending",
};

// ============================================
// 1. Classic for loop
// Calculate total cart value with early termination for budget limit
// ============================================

function calculateCartTotalWithBudget(cart: Product[], budget: number): { total: number; itemsIncluded: number; budgetExceeded: boolean } {
  let total: number = 0;
  let itemsIncluded: number = 0;
  let budgetExceeded: boolean = false;

  for (let i: number = 0; i < cart.length; i++) {
    if (total + cart[i].price > budget) {
      budgetExceeded = true;
      break; // Early termination when budget exceeded
    }
    total += cart[i].price;
    itemsIncluded++;
  }

  return { total, itemsIncluded, budgetExceeded };
}

const budgetResult = calculateCartTotalWithBudget(products, 1000);
console.log("Budget Check:", budgetResult);

// ============================================
// 2. for...of loop
// Process only in-stock products and generate shipping labels
// ============================================

interface ShippingLabel {
  productName: string;
  labelText: string;
}

function generateShippingLabels(inventory: Product[]): ShippingLabel[] {
  const labels: ShippingLabel[] = [];

  for (const product of inventory) {
    if (product.inStock) {
      labels.push({
        productName: product.name,
        labelText: `SHIP: ${product.name} (${product.category}) - $${product.price}`,
      });
    }
  }

  return labels;
}

const shippingLabels = generateShippingLabels(products);
console.log("\nShipping Labels:", shippingLabels);

// ============================================
// 3. for...in loop
// Analyze order status distribution
// ============================================

function analyzeOrderStatuses(orders: Record<string, string>): Record<string, number> {
  const statusCount: Record<string, number> = {};

  for (const orderId in orders) {
    const status: string = orders[orderId];
    statusCount[status] = (statusCount[status] || 0) + 1;
  }

  return statusCount;
}

const statusDistribution = analyzeOrderStatuses(orderStatuses);
console.log("\nOrder Status Distribution:", statusDistribution);

// ============================================
// 4. Nested loops
// Calculate student averages and find top performer
// ============================================

interface StudentResult {
  name: string;
  average: number;
  grade: string;
}

function calculateStudentResults(studentList: Student[]): { results: StudentResult[]; topPerformer: string } {
  const results: StudentResult[] = [];
  let highestAverage: number = 0;
  let topPerformer: string = "";

  for (const student of studentList) {
    let sum: number = 0;

    // Inner loop: iterate through scores
    for (const score of student.scores) {
      sum += score;
    }

    const average: number = sum / student.scores.length;

    // Determine grade
    let grade: string;
    if (average >= 90) grade = "A";
    else if (average >= 80) grade = "B";
    else if (average >= 70) grade = "C";
    else grade = "D";

    results.push({
      name: student.name,
      average: Math.round(average * 100) / 100,
      grade,
    });

    // Track top performer
    if (average > highestAverage) {
      highestAverage = average;
      topPerformer = student.name;
    }
  }

  return { results, topPerformer };
}

const studentResults = calculateStudentResults(students);
console.log("\nStudent Results:", studentResults.results);
console.log("Top Performer:", studentResults.topPerformer);

// ============================================
// 5. for...of with entries()
// Generate indexed inventory report with position-based formatting
// ============================================

interface InventoryReportItem {
  position: number;
  displayIndex: string;
  product: Product;
  priceTier: string;
}

function generateIndexedInventoryReport(inventory: Product[]): InventoryReportItem[] {
  const report: InventoryReportItem[] = [];

  for (const [index, product] of inventory.entries()) {
    // Determine price tier based on position and price
    let priceTier: string;
    if (product.price > 500) priceTier = "Premium";
    else if (product.price > 100) priceTier = "Standard";
    else priceTier = "Budget";

    report.push({
      position: index + 1,
      displayIndex: `ITEM-${String(index + 1).padStart(3, "0")}`,
      product,
      priceTier,
    });
  }

  return report;
}

const inventoryReport = generateIndexedInventoryReport(products);
console.log("\nIndexed Inventory Report:");
for (const item of inventoryReport) {
  console.log(`  ${item.displayIndex}: ${item.product.name} - ${item.priceTier} ($${item.product.price})`);
}

// ============================================
// Bonus: Classic for loop with step increment
// Generate pagination numbers
// ============================================

function generatePagination(currentPage: number, totalPages: number, visibleRange: number): number[] {
  const pages: number[] = [];
  const startPage: number = Math.max(1, currentPage - visibleRange);
  const endPage: number = Math.min(totalPages, currentPage + visibleRange);

  for (let page: number = startPage; page <= endPage; page++) {
    pages.push(page);
  }

  return pages;
}

const pagination = generatePagination(5, 20, 2);
console.log("\nPagination:", pagination);
