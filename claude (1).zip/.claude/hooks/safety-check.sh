#!/bin/bash
# Safety check hook for Bash commands
# This script validates Bash commands before execution

set -e

# Read JSON input from stdin
INPUT=$(cat)
COMMAND=$(echo "$INPUT" | jq -r '.tool_input.command // empty')

# Block list - commands that are too dangerous
BLOCKED_PATTERNS=(
  "rm -rf /"
  "rm -rf /*"
  "rm -rf ~"
  "rm -rf ~/*"
  "> /dev/sda"
  "mkfs."
  "dd if=.*of=/dev/sda"
  ":(){ :|:& };:"
  "chmod -R 777 /"
  "chmod -R 000 /"
  "sudo rm"
)

for pattern in "${BLOCKED_PATTERNS[@]}"; do
  if echo "$COMMAND" | grep -qE "$pattern"; then
    echo "{
      \"hookSpecificOutput\": {
        \"hookEventName\": \"PreToolUse\",
        \"permissionDecision\": \"deny\",
        \"permissionDecisionReason\": \"Command blocked: dangerous operation detected ($pattern)\"\n      }
    }"
    exit 0
  fi
done

# Warning list - commands that need extra confirmation
WARNING_PATTERNS=(
  "rm -rf"
  "git push --force"
  "git push -f"
  "drop database"
  "DROP DATABASE"
  "docker system prune"
  "docker volume prune"
)

for pattern in "${WARNING_PATTERNS[@]}"; do
  if echo "$COMMAND" | grep -qE "$pattern"; then
    echo "{
      \"hookSpecificOutput\": {
        \"hookEventName\": \"PreToolUse\",
        \"permissionDecision\": \"ask\",
        \"permissionDecisionReason\": \"Warning: Potentially destructive command detected ($pattern). Please confirm.\"\n      }
    }"
    exit 0
  fi
done

# Allow the command
exit 0
