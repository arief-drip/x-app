#!/bin/bash
# Orchestrator Guard Hook
# Blocks orchestrator from using implementation tools
# Enforces read-only policy for main agent

# Read tool input from stdin
TOOL_INPUT=$(cat)

# Extract tool name from input
TOOL_NAME=$(echo "$TOOL_INPUT" | jq -r '.tool_name // empty')

# For now, this hook runs on Edit/Write matchers
# We need to check if this is being called from the main thread (orchestrator)
# vs a subagent

# If CLAUDE_AGENT_NAME is set and not empty, it's a subagent
if [ -n "$CLAUDE_AGENT_NAME" ]; then
    # This is a subagent, allow the operation
    exit 0
fi

# No CLAUDE_AGENT_NAME means main orchestrator
# Block implementation tools
echo '{
  "permissionDecision": "block",
  "decision": "Orchestrator is READ-ONLY. Delegate to implementer subagent using Task tool.",
  "message": "Orchestrator tidak boleh mengedit/menulis file. Gunakan subagent implementer dengan Task tool.",
  "display": "error"
}'
exit 2
