#!/bin/bash
# Session initialization hook
# Runs asynchronously at session start

set -e

# Get session info from stdin (for potential logging)
INPUT=$(cat)
SESSION_ID=$(echo "$INPUT" | jq -r '.session_id // empty')
CWD=$(echo "$INPUT" | jq -r '.cwd // empty')

# Log session start (optional - comment out if not needed)
# echo "[$(date)] Session $SESSION_ID started in $CWD" >> ~/.claude/session-log.txt

# Set useful environment variables if CLAUDE_ENV_FILE is available
if [ -n "$CLAUDE_ENV_FILE" ]; then
  # Add common tool paths
  echo 'export PATH="$PATH:./node_modules/.bin:$HOME/.local/bin"' >> "$CLAUDE_ENV_FILE"

  # Set default editor if not set
  if [ -z "$EDITOR" ]; then
    echo 'export EDITOR="code --wait"' >> "$CLAUDE_ENV_FILE"
  fi

  # Enable colored output
  echo 'export CLICOLOR=1' >> "$CLAUDE_ENV_FILE"
  echo 'export LSCOLORS=ExFxBxDxCxegedabagacad' >> "$CLAUDE_ENV_FILE"
fi

exit 0
