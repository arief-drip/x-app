#!/bin/bash
# Post-Task Reminder Hook
# Reminds orchestrator to run reviewer after implementer tasks

TOOL_INPUT=$(cat)
AGENT_PROMPT=$(echo "$TOOL_INPUT" | jq -r '.tool_input.prompt // empty')

# Check if this was an implementer task
if echo "$AGENT_PROMPT" | grep -qi "implementer"; then
    echo '{
      "permissionDecision": "allow",
      "message": "⚠️  IMPLEMENTER TASK COMPLETED → NEXT: Spawn REVIEWER subagent before presenting to user!",
      "display": "info"
    }'
    exit 0
fi

# Check if this was a researcher task
if echo "$AGENT_PROMPT" | grep -qi "researcher"; then
    echo '{
      "permissionDecision": "allow",
      "message": "⚠️  RESEARCHER TASK COMPLETED → NEXT: Spawn IMPLEMENTER subagent!",
      "display": "info"
    }'
    exit 0
fi

exit 0
