# Security Guidelines

## Input Validation
- Validasi semua user input sebelum diproses
- Sanitize data sebelum insert ke database atau rendering HTML
- Gunakan parameterized queries untuk SQL

## File Access
- Jangan baca file: `.env`, `.env.*`, `secrets/**`, `~/.ssh/*`, `~/.aws/*`
- Jangan commit: credential files, API keys, private keys
- Quote path variables: `"$FILE_PATH"` bukan `$FILE_PATH`

## Command Execution
- Hindari `eval` dengan user input
- Periksa path traversal (`..`) dalam file paths
- Gunakan absolute paths untuk command penting

## Network Security
- Validasi URLs sebelum fetch/download
- Periksa SSL certificates untuk production
- Limit redirect follows
