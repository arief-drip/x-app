---
paths:
  - "**/.git/**"
---

# Git Workflow Rules

## Pre-commit Checks
- Selalu jalankan `git diff --check` untuk memeriksa whitespace errors
- Pastikan tidak ada file besar yang tidak sengaja di-commit

## Commit Message Style
- Gunakan format: `<type>: <subject>`
- Types: feat, fix, docs, style, refactor, test, chore
- Subject: maksimal 50 karakter, gunakan imperative mood

## Protected Operations
- Tanya konfirmasi sebelum: `git push --force`, `git rebase -i`, `git reset --hard`
- Selalu backup branch sebelum operasi destruktif: `git branch backup-<nama-branch>`
